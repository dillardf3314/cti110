num1 =int(input())
num2 = int(input())
sum = num1 + num2
result = num1 * num2
print(num1)
print(num2)
print(num1+num2)
print(num1*num2)



 




