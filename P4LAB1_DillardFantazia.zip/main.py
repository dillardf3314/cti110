user_text = input()
chars = 0
   
for i in user_text:
 if i != ' ' and i != '.' and i != '!' and i != ',':
    chars += 1


print(chars)
