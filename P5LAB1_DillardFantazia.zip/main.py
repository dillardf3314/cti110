# Define your function here 
def laps_to_miles(user_laps):
    miles = user_laps * .25
    return miles

if __name__ == '__main__':
    # Type your code here. Your code must call the function. 
    user_laps = float(input())
    miles = laps_to_miles(user_laps)
    print(f'{miles:.2f}')