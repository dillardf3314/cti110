red = int(input())
green = int(input())
blue = int(input())

gray = red
if green < gray:
 gray = green
if blue < gray :
 gray = blue

if red >=  gray :
 red = red - gray
if green >= gray :
 green = green - gray
if blue >= gray :
 blue = blue - gray

print( red, green, blue)