user_int = int(input('Enter integer (32 - 126):\n'))
user_float = float(input('Enter float:\n'))
user_character = input('Enter character:\n')
user_string = str(input('Enter string:\n'))

print(user_int, user_float, user_character, user_string)
print(user_string, user_character, user_float, user_int)
print(user_int,'converted to a character is', chr(user_int))

